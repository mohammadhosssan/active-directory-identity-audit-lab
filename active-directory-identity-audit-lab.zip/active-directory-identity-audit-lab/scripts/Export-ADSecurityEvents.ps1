[CmdletBinding()]
param(
    [datetime]$Since = (Get-Date).AddDays(-7),
    [string]$OutputPath = (Join-Path $PSScriptRoot '..\reports\security-events.csv')
)

$ErrorActionPreference = 'Stop'
$eventIds = 4720,4722,4725,4726,4728,4729,4732,4733,4740
try {
    $events = Get-WinEvent -FilterHashtable @{ LogName = 'Security'; Id = $eventIds; StartTime = $Since } -ErrorAction Stop
} catch [System.Diagnostics.Eventing.Reader.EventLogException] {
    throw 'Could not read the Security log. Run elevated and confirm the required audit policy is enabled.'
} catch {
    if ($_.FullyQualifiedErrorId -like '*NoMatchingEventsFound*') { $events = @() } else { throw }
}
$rows = foreach ($event in $events) {
    [pscustomobject]@{
        TimeCreated = $event.TimeCreated
        EventId = $event.Id
        EventName = switch ($event.Id) {
            4720 {'User account created'} 4722 {'User account enabled'} 4725 {'User account disabled'}
            4726 {'User account deleted'} 4728 {'Member added to security-enabled global group'}
            4729 {'Member removed from security-enabled global group'} 4732 {'Member added to security-enabled local group'}
            4733 {'Member removed from security-enabled local group'} 4740 {'Account locked out'}
            default {'Other'}
        }
        RecordId = $event.RecordId
        Message = ($event.Message -replace '\r?\n',' | ')
    }
}
$parent = Split-Path -Parent $OutputPath
if ($parent) { New-Item -ItemType Directory -Path $parent -Force | Out-Null }
$rows | Sort-Object TimeCreated -Descending | Export-Csv -NoTypeInformation -Encoding UTF8 -Path $OutputPath
Write-Host "Exported $(@($rows).Count) matching events since $Since to $OutputPath"
