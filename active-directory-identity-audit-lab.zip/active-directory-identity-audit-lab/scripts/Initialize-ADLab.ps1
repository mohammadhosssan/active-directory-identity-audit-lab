[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [Parameter(Mandatory = $true)]
    [ValidatePattern('^(DC=[^,]+)(,DC=[^,]+)*$')]
    [string]$DomainDN,
    [string]$UsersCsv = (Join-Path $PSScriptRoot '..\data\users.csv'),
    [string]$GroupsCsv = (Join-Path $PSScriptRoot '..\data\department-groups.csv')
)

$ErrorActionPreference = 'Stop'
Import-Module ActiveDirectory
$domain = Get-ADDomain
if ($domain.DistinguishedName -ne $DomainDN) {
    throw "The supplied DomainDN does not match this computer's domain ($($domain.DistinguishedName)). Stopping to avoid writing to the wrong domain."
}
if (-not (Test-Path -LiteralPath $UsersCsv) -or -not (Test-Path -LiteralPath $GroupsCsv)) {
    throw 'Could not find one or both CSV input files.'
}
$securePassword = Read-Host 'Enter a lab-only initial password (minimum 12 characters)' -AsSecureString
if ($securePassword.Length -lt 12) { throw 'Initial password must be at least 12 characters.' }

$usersOUName = 'Lab Users'
$groupsOUName = 'Lab Groups'
$usersOU = "OU=$usersOUName,$DomainDN"
$groupsOU = "OU=$groupsOUName,$DomainDN"
foreach ($ou in @(@{Name=$usersOUName; DN=$usersOU}, @{Name=$groupsOUName; DN=$groupsOU})) {
    if (-not (Get-ADOrganizationalUnit -Filter "Name -eq '$($ou.Name)'" -SearchBase $DomainDN -SearchScope OneLevel)) {
        if ($PSCmdlet.ShouldProcess($ou.DN, 'Create lab organizational unit')) {
            New-ADOrganizationalUnit -Name $ou.Name -Path $DomainDN -ProtectedFromAccidentalDeletion $true | Out-Null
            Write-Host "Created OU: $($ou.DN)"
        }
    } else { Write-Host "Exists: $($ou.DN)" }
}

$groupMap = @{}
foreach ($row in (Import-Csv -LiteralPath $GroupsCsv)) {
    $group = Get-ADGroup -Filter "SamAccountName -eq '$($row.GroupName)'" -SearchBase $groupsOU -ErrorAction SilentlyContinue
    if (-not $group) {
        if ($PSCmdlet.ShouldProcess($row.GroupName, 'Create global security group')) {
            $group = New-ADGroup -Name $row.GroupName -SamAccountName $row.GroupName -GroupScope Global -GroupCategory Security -Path $groupsOU -Description $row.Description -PassThru
            Write-Host "Created group: $($row.GroupName)"
        }
    } else { Write-Host "Exists: $($row.GroupName)" }
    $groupMap[$row.Department] = $row.GroupName
}

$created = 0; $existing = 0; $assigned = 0
foreach ($row in (Import-Csv -LiteralPath $UsersCsv)) {
    if ($row.SamAccountName -notmatch '^[a-zA-Z0-9._-]{1,20}$') { throw "Invalid sAMAccountName: $($row.SamAccountName)" }
    $user = Get-ADUser -Filter "SamAccountName -eq '$($row.SamAccountName)'" -SearchBase $usersOU -ErrorAction SilentlyContinue
    if (-not $user) {
        if ($PSCmdlet.ShouldProcess($row.SamAccountName, 'Create enabled lab user')) {
            $upn = "$($row.SamAccountName)@$($domain.DNSRoot)"
            New-ADUser -Name "$($row.GivenName) $($row.Surname)" -GivenName $row.GivenName -Surname $row.Surname `
                -SamAccountName $row.SamAccountName -UserPrincipalName $upn -EmailAddress $row.Email `
                -Department $row.Department -Title $row.Title -Path $usersOU -AccountPassword $securePassword `
                -Enabled $true -ChangePasswordAtLogon $true | Out-Null
            $user = Get-ADUser -Identity $row.SamAccountName -Properties Enabled
            $created++
            Write-Host "Created user: $($row.SamAccountName)"
        }
    } else {
        if ($PSCmdlet.ShouldProcess($row.SamAccountName, 'Refresh lab profile fields (preserve enabled state)')) {
            Set-ADUser -Identity $user -GivenName $row.GivenName -Surname $row.Surname -EmailAddress $row.Email -Department $row.Department -Title $row.Title
        }
        $existing++
        Write-Host "Exists; account state preserved: $($row.SamAccountName)"
    }
    if ($user -and $groupMap.ContainsKey($row.Department)) {
        $groupName = $groupMap[$row.Department]
        $member = Get-ADGroupMember -Identity $groupName -Recursive | Where-Object { $_.DistinguishedName -eq $user.DistinguishedName }
        if (-not $member -and $PSCmdlet.ShouldProcess($row.SamAccountName, "Add to $groupName")) {
            Add-ADGroupMember -Identity $groupName -Members $user
            $assigned++
        }
    }
}
Write-Host "`nCompleted. New users: $created; existing users: $existing; new group assignments: $assigned."
Write-Host 'No privileged groups were modified. Existing disabled accounts were not re-enabled.'
