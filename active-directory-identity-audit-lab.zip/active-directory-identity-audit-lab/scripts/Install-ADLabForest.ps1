[CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
param(
    [ValidatePattern('^(?=.{1,253}$)([a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,63}$')]
    [string]$DomainName = 'adlab.local',
    [ValidatePattern('^[A-Z0-9]{1,15}$')]
    [string]$NetBIOSName = 'ADLAB'
)

$ErrorActionPreference = 'Stop'

if ($env:OS -ne 'Windows_NT') {
    throw 'Run this script from Windows Server PowerShell inside a disposable lab VM.'
}
$os = Get-CimInstance -ClassName Win32_OperatingSystem
if ($os.ProductType -ne 3) {
    throw 'This script requires Windows Server. It will not run on Windows client or an existing domain controller.'
}
$computer = Get-CimInstance -ClassName Win32_ComputerSystem
if ($computer.PartOfDomain) {
    throw 'Use a fresh standalone Windows Server VM that is not joined to a domain.'
}
$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = [Security.Principal.WindowsPrincipal]::new($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'Open Windows PowerShell as Administrator and run this script again.'
}

$dsrmPassword = Read-Host 'Enter a unique DSRM recovery password for this disposable lab VM' -AsSecureString
if ($dsrmPassword.Length -lt 8) {
    throw 'The DSRM password is too short. Use a strong, unique password.'
}

$target = "new forest $DomainName (NetBIOS $NetBIOSName)"
if ($PSCmdlet.ShouldProcess($target, 'Install AD DS and promote this server; the VM will restart')) {
    Import-Module ServerManager
    $feature = Get-WindowsFeature -Name AD-Domain-Services
    if (-not $feature.Installed) {
        Install-WindowsFeature -Name AD-Domain-Services -IncludeManagementTools | Out-Null
    }
    Import-Module ADDSDeployment
    Install-ADDSForest `
        -DomainName $DomainName `
        -DomainNetbiosName $NetBIOSName `
        -InstallDns `
        -SafeModeAdministratorPassword $dsrmPassword `
        -Force
}
