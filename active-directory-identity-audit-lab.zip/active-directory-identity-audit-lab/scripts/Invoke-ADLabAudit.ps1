[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidatePattern('^(DC=[^,]+)(,DC=[^,]+)*$')]
    [string]$DomainDN,
    [string]$OutputDirectory = (Join-Path $PSScriptRoot '..\reports'),
    [ValidateRange(1,3650)]
    [int]$StaleAfterDays = 45
)

$ErrorActionPreference = 'Stop'
Import-Module ActiveDirectory
$domain = Get-ADDomain
if ($domain.DistinguishedName -ne $DomainDN) { throw 'DomainDN does not match the current domain.' }
$usersOU = "OU=Lab Users,$DomainDN"
if (-not (Get-ADOrganizationalUnit -Identity $usersOU -ErrorAction SilentlyContinue)) { throw "Lab OU not found: $usersOU. Run Initialize-ADLab.ps1 first." }
New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
$cutoff = (Get-Date).AddDays(-$StaleAfterDays)
$now = Get-Date
$findings = foreach ($u in (Get-ADUser -Filter * -SearchBase $usersOU -Properties Enabled,LastLogonTimestamp,PasswordNeverExpires,PasswordLastSet,Mail,Department,Title)) {
    $lastLogon = if ($u.LastLogonTimestamp) { [DateTime]::FromFileTime($u.LastLogonTimestamp) } else { $null }
    $status = if (-not $u.Enabled) { 'Disabled account' } elseif (-not $lastLogon) { 'Never logged on' } elseif ($lastLogon -lt $cutoff) { 'Stale logon' } elseif ($u.PasswordNeverExpires) { 'Password never expires' } else { 'No finding' }
    $groupNames = (Get-ADPrincipalGroupMembership -Identity $u | Where-Object { $_.Name -like 'GG-*' } | Select-Object -ExpandProperty Name) -join '; '
    [pscustomobject]@{
        SamAccountName = $u.SamAccountName
        Name = $u.Name
        Department = $u.Department
        Title = $u.Title
        Enabled = $u.Enabled
        LastLogonApprox = $lastLogon
        DaysSinceLogonApprox = if ($lastLogon) { [math]::Floor(($now - $lastLogon).TotalDays) } else { $null }
        PasswordNeverExpires = $u.PasswordNeverExpires
        PasswordLastSet = $u.PasswordLastSet
        RoleGroups = $groupNames
        Finding = $status
    }
}
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$csvPath = Join-Path $OutputDirectory "ad-identity-audit-$stamp.csv"
$htmlPath = Join-Path $OutputDirectory "ad-identity-audit-$stamp.html"
$findings | Sort-Object Finding,SamAccountName | Export-Csv -NoTypeInformation -Encoding UTF8 -Path $csvPath
$styles = '<style>body{font:15px Segoe UI,Arial;margin:32px;color:#172033}h1{color:#123b66}.note{color:#526277}table{border-collapse:collapse;width:100%}th{background:#123b66;color:white;text-align:left}th,td{padding:9px;border:1px solid #d8e0ea}tr:nth-child(even){background:#f2f6fa}.No-finding{color:#18794e}</style>'
$body = $findings | Sort-Object Finding,SamAccountName | ConvertTo-Html -Property SamAccountName,Name,Department,Enabled,LastLogonApprox,DaysSinceLogonApprox,PasswordNeverExpires,RoleGroups,Finding -Fragment
$html = ConvertTo-Html -Title 'AD Lab Identity Audit' -Head $styles -Body "<h1>Active Directory Identity Audit</h1><p>Generated: $now | Domain: $($domain.DNSRoot) | Stale threshold: $StaleAfterDays days</p><p class='note'>Lab report. LastLogonTimestamp is approximate and can lag replication. Validate findings before acting.</p>$body"
$html | Out-File -Encoding utf8 -FilePath $htmlPath
Write-Host "Audit complete. CSV: $csvPath"
Write-Host "Audit complete. HTML: $htmlPath"
Write-Host "Accounts reviewed: $($findings.Count); findings: $(($findings | Where-Object Finding -ne 'No finding').Count)."
