# Create the Windows Server lab VM

This guide builds an isolated, disposable domain controller. Use a Windows Server evaluation ISO obtained from Microsoft's official evaluation source and follow its license terms.

## VM settings

- VM name: `DC01`
- Guest OS: Windows Server 2022 Desktop Experience
- Resources: 2 virtual CPUs, 4–8 GB RAM, and 60 GB or more virtual disk
- Network: an **internal/private virtual switch** with no bridge to a production network
- Optional client VM: Windows 11 on the same isolated switch

Hyper-V and VirtualBox both work. The exact menus differ by version; make sure the DC and client use the same isolated virtual network. Do not use bridged networking for this lab.

## Prepare the server

1. Install Windows Server in the VM and set a unique local Administrator password.
2. Rename the server `DC01` and restart it.
3. Keep the VM disconnected from production networks. A static address is recommended; if using a second Windows client, assign both machines addresses on the same private subnet.
4. Take a clean VM snapshot before promoting the server.

## Create the forest

Copy this project folder into the VM. Open **Windows PowerShell as Administrator**, change to the project folder, and run:

```powershell
Set-ExecutionPolicy -Scope Process RemoteSigned
.\scripts\Install-ADLabForest.ps1 -DomainName 'adlab.local' -NetBIOSName 'ADLAB'
```

Review the requested operation and confirm it. The script checks that it is running on Windows Server, that the machine is not already domain-joined, and that the shell is elevated. It installs AD DS, creates a new forest, configures DNS, and restarts the VM. Use a unique DSRM password; this is separate from the domain Administrator password.

After restart, sign in as `ADLAB\Administrator`. Then continue with [LAB-GUIDE.md](LAB-GUIDE.md) to create the demo OUs and accounts, run the reports, and enable audit policy.

## Evidence capture

Capture the actual VM after each step using the [screenshot checklist](SCREENSHOT-CHECKLIST.md). The first useful evidence is Server Manager showing AD DS installed and ADUC showing `adlab.local`. The screenshot checklist covers the rest.
