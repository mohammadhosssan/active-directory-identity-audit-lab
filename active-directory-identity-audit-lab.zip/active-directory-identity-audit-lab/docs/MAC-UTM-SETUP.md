# Windows Server 2022 on an Apple silicon Mac

1. On the Mac, download the stable UTM disk image, open it in Finder, drag UTM to Applications, and open UTM. [Official UTM installation guide](https://docs.getutm.app/installation/macos/)
2. On the Mac, choose your language and **ISO downloads → 64-bit edition**. Keep the installer in Downloads. Microsoft lists a 180-day evaluation and an internet activation requirement within 10 days to avoid automatic shutdown. Plan the offline exercise accordingly. [Windows Server 2022 Evaluation Center](https://www.microsoft.com/en-us/evalcenter/download-windows-server-2022)
3. In UTM click **+ → Emulate → Windows**, browse to the ISO, and choose **x86_64** (Intel/AMD 64-bit). Allocate 8192 MiB, 2 CPU cores and a fresh 80 GiB disk. Leave the shared directory empty. Name the VM DC01 and open its settings before starting it.
4. Use one network adapter, **Host Only**, with **Intel E1000** emulation. Choose a dedicated host network if offered. Leave port forwarding empty and keep macOS Internet Sharing off. Use an IDE/SATA-compatible system disk if Windows Setup cannot see a disk. [UTM QEMU network settings](https://docs.getutm.app/settings-qemu/devices/network/network/)
5. Start DC01, boot from the ISO and select **Windows Server 2022 Standard Evaluation (Desktop Experience) → Custom**. Select the new empty virtual disk. After Setup restarts, boot from the virtual disk. Set a unique local Administrator password in the VM console.
6. In the guest, open **ncpa.cpl → Ethernet → Properties → Internet Protocol Version 4 → Properties**. On a dedicated lab segment use 192.168.77.10, mask 255.255.255.0, preferred DNS 192.168.77.10 and a blank gateway. If that subnet overlaps a physical network or VPN, choose an unused private subnet. Leave IPv6 enabled.

**Windows PowerShell inside DC01, as Administrator**

```powershell
Get-NetIPConfiguration | Select-Object InterfaceAlias,IPv4Address,IPv4DefaultGateway
Get-NetRoute | Where-Object DestinationPrefix -in '0.0.0.0/0','::/0'
(Get-CimInstance Win32_OperatingSystem).Caption
Rename-Computer -NewName DC01 -Restart
```

Check that exactly one lab adapter has the static address, the route query returns no default route, and the caption identifies Windows Server 2022. Rename only if needed.

## Copy the project offline

**Mac Terminal**, from the repository root, builds a read-only transfer disc.

```zsh
stage=$(mktemp -d)
cp -R README.md LICENSE scripts data docs evidence reports "$stage/"
hdiutil makehybrid -iso -joliet -default-volume-name ADLABFILES -o "$stage/../ADLabFiles-$(basename "$stage").iso" "$stage"
```

The last command prints the ISO path. In UTM use the CD/DVD drive menu, eject the Windows installer after setup, and choose the project ISO. In Windows, open elevated Windows PowerShell and copy the files to a writable folder.

```powershell
$disc = Get-Volume -FileSystemLabel ADLABFILES -ErrorAction Stop
New-Item -ItemType Directory -Force C:\ADLab | Out-Null
Copy-Item "$($disc.DriveLetter):\*" -Destination C:\ADLab -Recurse -Force
Set-Location C:\ADLab
Get-ChildItem .\scripts\*.ps1 -Name
```

Expect four scripts. Continue with the [guest verification steps](LAB-GUIDE.md).
