# Screenshot checklist

Capture these from your own completed VM. Use 1366×768 or higher, maximize the window, and crop out unrelated desktop clutter. Keep text large enough to read. Do not include passwords, license keys, personal accounts, or unrelated notifications.

Save images in `evidence/` using the filenames below, then embed them in the main README.

| Filename | What to show | Recruiter takeaway |
|---|---|---|
| `01-domain-and-ou-structure.png` | ADUC with `adlab.local`, `Lab Users`, and `Lab Groups` visible | You built and organized a real AD domain |
| `02-role-groups-and-members.png` | Role membership from Get-ADGroupMember or a group’s Members tab | You understand role-based group assignment |
| `03-provisioning-run.png` | PowerShell run showing created/skipped counts; no secrets | You can automate onboarding and handle reruns |
| `03b-provisioning-rerun.png` | PowerShell summary showing zero new users and memberships | A repeat run reuses the same objects |
| `04-audit-report.png` | HTML audit report in browser with demo-only rows | You can turn directory state into readable findings |
| `05-security-events.png` | Event Viewer or exported CSV showing a generated account/group event | You can connect changes to audit evidence |
| `06-client-domain-join.png` | Optional Windows client showing it joined to `adlab.local` | You can demonstrate a client-to-domain workflow |

## Capture tips

- Capture one clear image per claim; avoid a collage of tiny windows.
- Use fictional demo accounts only. The repository data is fictional.
- For `03`, crop the first-run output to the creation counts. Capture the rerun counts separately and verify that all eight object IDs match.
- For `04`, use the generated report from `reports/`; zoom the browser until the status and finding columns are legible.
- For `05`, show the target account and match the exported record ID against the original Security event.
- Before committing, inspect every screenshot at full size and remove any secrets or machine-specific details you do not want public.
