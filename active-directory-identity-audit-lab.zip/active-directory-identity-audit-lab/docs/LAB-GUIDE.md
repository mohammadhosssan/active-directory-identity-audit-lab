# Run and verify the single-DC lab

All commands here run in **Windows PowerShell as Administrator inside DC01**. Start with the [Mac and UTM setup](MAC-UTM-SETUP.md) or [general VM setup](VM-SETUP.md). Use a fresh lab with the supplied CSVs.

## Create the forest

```powershell
cd C:\ADLab
Set-ExecutionPolicy -Scope Process RemoteSigned
.\scripts\Install-ADLabForest.ps1 -DomainName adlab.local -NetBIOSName ADLAB
```

Enter a separate lab-only DSRM password, confirm promotion, and allow the restart. Sign in as ADLAB\Administrator. In a new elevated shell run the remaining blocks in order. Stop at the first unexpected result.

```powershell
cd C:\ADLab
Set-ExecutionPolicy -Scope Process RemoteSigned
$ErrorActionPreference = 'Stop'
Import-Module ActiveDirectory
$domain = Get-ADDomain
$domain | Select-Object DNSRoot,DistinguishedName,PDCEmulator
if ($domain.DNSRoot -ne 'adlab.local') { throw 'Unexpected domain' }
$dn = $domain.DistinguishedName
```

## Prove provisioning is repeatable

```powershell
function Get-LabObjects {
    Get-ADUser -Filter * -SearchBase "OU=Lab Users,$dn"
    Get-ADGroup -Filter * -SearchBase "OU=Lab Groups,$dn"
}
.\scripts\Initialize-ADLab.ps1 -DomainDN $dn
$before = Get-LabObjects | Select-Object -ExpandProperty ObjectGUID
.\scripts\Initialize-ADLab.ps1 -DomainDN $dn
$after = Get-LabObjects
$after | Group-Object ObjectClass | Select-Object Name,Count
if (Compare-Object $before $after.ObjectGUID) { throw 'Object identities changed on rerun' }
$after | Where-Object ObjectClass -eq group | ForEach-Object {
    [pscustomobject]@{Group=$_.Name; Members=((Get-ADGroupMember $_ | Sort-Object SamAccountName).SamAccountName -join ', ')}
}
```

Expect five users and three groups on both runs. The rerun should report zero new users and assignments. Finance should contain mpatel and nguyen, IT ohassan and roberts, and Operations chen. In dsa.msc expand the domain and inspect **Lab Groups → GG-Finance-Staff → Properties → Members**.

## Compare the reports and trace the change

Enable auditing before the controlled change. These local audit settings apply to the disposable DC. If effective policy differs, enable success auditing for the same subcategories in a GPO linked to the Domain Controllers OU, run gpupdate /force, and recheck.

```powershell
auditpol /set /subcategory:"User Account Management" /success:enable
auditpol /set /subcategory:"Security Group Management" /success:enable
auditpol /get /category:"Account Management"
```

Confirm both subcategories include Success. Use separate directories to keep the two reports identifiable.

```powershell
.\scripts\Invoke-ADLabAudit.ps1 -DomainDN $dn -OutputDirectory .\reports\before
$user = Get-ADUser -Identity "CN=Mina Patel,OU=Lab Users,$dn"
if (!$user.Enabled) { throw 'Expected an enabled baseline for mpatel' }
$since = Get-Date
Disable-ADAccount -Identity $user
.\scripts\Invoke-ADLabAudit.ps1 -DomainDN $dn -OutputDirectory .\reports\after
foreach ($phase in 'before','after') {
    $file = Get-ChildItem ".\reports\$phase\*.csv" | Sort-Object LastWriteTime -Descending | Select-Object -First 1
    $row = Import-Csv $file.FullName | Where-Object SamAccountName -eq mpatel
    $row | Select-Object SamAccountName,Enabled,Finding
    if ($phase -eq 'before' -and $row.Enabled -ne 'True') { throw 'Missing enabled baseline' }
    if ($phase -eq 'after' -and ($row.Enabled -ne 'False' -or $row.Finding -ne 'Disabled account')) { throw 'Missing disable finding' }
}
Invoke-Item (Get-ChildItem .\reports\after\*.html | Sort-Object LastWriteTime -Descending | Select-Object -First 1).FullName
.\scripts\Export-ADSecurityEvents.ps1 -Since $since -OutputPath .\reports\security-events.csv
$match = Import-Csv .\reports\security-events.csv | Where-Object { $_.EventId -eq '4725' -and $_.Message -match '\bmpatel\b' }
if (!$match) { throw 'No matching disable event. Recheck effective audit policy and the local Security log.' }
$match | Select-Object TimeCreated,EventId,EventName,RecordId
```

To inspect the original record, in Event Viewer open **Windows Logs → Security → Filter Current Log**, enter **4725**, and match the record ID in **Details** and the target account mpatel. Use the [screenshot checklist](SCREENSHOT-CHECKLIST.md). On the Mac, Shift-Command-4 lets you capture just the relevant guest region. Save the reviewed PNGs in the Mac project's evidence folder.
